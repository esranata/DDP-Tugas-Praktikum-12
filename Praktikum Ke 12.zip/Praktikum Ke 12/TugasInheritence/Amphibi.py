from Animal import Animal

# Setiap class itu memiliki 2 properti dan method
class Amphibi(Animal):
    def __init__(self, name, makanan, hidup, berkembang_biak, jenis_air, bernapas):
        super().__init__(name, makanan, hidup, berkembang_biak)
        self.jenis_air = jenis_air
        self.bernapas = bernapas
    def info_amphibi(self):
        super().info_animal(),
        print("Jenis Air \t\t\t : ", self.jenis_air,
              "\nBernafas \t\t\t : ",self.bernapas)
        
amphini = Amphibi("Katak", "Serangga", "Dua Alam", "Bertelur", "Air Tawar", "Kulit dan Paru-Paru")
amphini.info_amphibi()


    