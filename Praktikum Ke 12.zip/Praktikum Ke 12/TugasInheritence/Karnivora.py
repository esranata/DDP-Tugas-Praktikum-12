from  Animal import Animal

class Karnivora(Animal):
    def __init__(self, name, makakanan, hidup, berkembang_biak, ukuran_tubuh, jenis_gigi):
        super().__init__(name, makakanan, hidup, berkembang_biak)
        self.ukuran_tubuh = ukuran_tubuh
        self.jenis_gigi = jenis_gigi
    
    def info_karnivora(self):
       super().info_animal(),
       print("Ukuran_Tubuh \t\t\t : ", self.ukuran_tubuh,
             "\nJenis_Gigi \t\t\t : ", self.jenis_gigi)

karnivora = Karnivora("Harimau", "Daging", "Darat", "Melahirkan", "besar", "bertaring")
karnivora.info_karnivora()
        