from  Animal import Animal

class Mamalia(Animal):
    def __init__(self, name, makakanan, hidup, berkembang_biak, ukuran_tubuh, jenis_kulit):
        super().__init__(name, makakanan, hidup, berkembang_biak)
        self.ukuran_tubuh = ukuran_tubuh
        self.jenis_kulit = jenis_kulit
    
    def info_mamalia(self):
       super().info_animal(),
       print("Ukuran_Tubuh \t\t\t : ", self.ukuran_tubuh,
             "\nJenis_Kulit \t\t\t : ", self.jenis_kulit)

mamalia = Mamalia("Gajah", "Tumbuh-tumbuhan", "Darat", "Melahirkan", "besar", "Kulit tebal")
mamalia.info_mamalia()
        


