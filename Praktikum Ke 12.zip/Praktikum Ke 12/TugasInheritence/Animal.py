# Buat Class animal sebagaiparent class.class animal mempunyai properti 4 properti (nama, makanan, hidup, berkembang biak)

class Animal:
    def __init__(self, nama, makanan, hidup, berkembang_biak):
        self.nama = nama
        self.makanan = makanan
        self.hidup = hidup
        self.berkembang_biak = berkembang_biak

    def info_animal(self):
        print("Nama Hewan \t\t\t : ", self.nama,
            "\nMakanan \t\t\t : ", self.makanan,
            "\nHidup \t\t\t\t : ", self.hidup,
            "\nBerkembang Biak \t\t : ", self.berkembang_biak)

#hewan = Animal("Kucing", "ikan", "Darat", "Melahirkan")
#hewan.info_animal()

# Buat minimal 3 class child (Ampi)
               